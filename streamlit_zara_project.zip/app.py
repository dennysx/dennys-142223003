
import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt

st.set_page_config(page_title="Zara Sales Dashboard", layout="wide")

st.title("📊 Zara Sales Dashboard")

# Load data
df = pd.read_csv("zara.csv")

st.subheader("Dataset Preview")
st.dataframe(df)

st.subheader("Basic Statistics")
st.write(df.describe())

# Sales by Category
st.subheader("Sales Volume by Category")
sales_by_category = df.groupby("category")["sales_volume"].sum()

fig, ax = plt.subplots()
sales_by_category.plot(kind="bar", ax=ax)
ax.set_ylabel("Sales Volume")
ax.set_xlabel("Category")

st.pyplot(fig)

# Promotion filter
st.subheader("Filter by Promotion")
promo_filter = st.selectbox("Choose Promotion Status", df["promotion"].unique())

filtered_df = df[df["promotion"] == promo_filter]
st.dataframe(filtered_df)

st.success("Dashboard berhasil dijalankan 🚀")
