
# Zara Sales Dashboard

Project Streamlit sederhana untuk analisis data penjualan Zara.

## Cara Menjalankan
```bash
pip install -r requirements.txt
streamlit run app.py
```
